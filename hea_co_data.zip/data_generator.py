import os
import csv
from ase.io import read, write

surface_file_path = '/Users/chenghao/SynologyDrive/research/agaualcuptpd/hea_adsorption/agaualptpd/kpts441/hea_surface'
adsorption_file_path = '/Users/chenghao/SynologyDrive/research/agaualcuptpd/hea_adsorption/agaualptpd/kpts441/hea_co'

data_path = './'

Ecog = -14.327528

start_n = 0
stop_n = 500

exception_list = [3,112,124,245,255,298,353,371,470]

id_prop_list = []
# generate cif files
for sid in range(start_n, stop_n):
    if sid not in exception_list:
        surface_path = os.path.join(surface_file_path, 's{}.txt'.format(sid))
        adsorption_path = os.path.join(adsorption_file_path, 's{}.txt'.format(sid))

        models = read(adsorption_path, ':')
        Esurface = read(surface_path, -1).get_total_energy()

        for fid, model in enumerate(models):
            sysname = 's{}_f{}'.format(sid,fid)
            E_ade = model.get_total_energy() - Esurface - Ecog
            id_prop_list.append((sysname,E_ade))
            write(os.path.join(data_path, '{}.cif'.format(sysname)), model)

# print(id_prop_list)
# exit(0)

# generate id_prop csv file
with open(os.path.join(data_path, 'id_prop.csv'), 'w') as f:
    csv_write = csv.writer(f)
    csv_write.writerows(id_prop_list)
